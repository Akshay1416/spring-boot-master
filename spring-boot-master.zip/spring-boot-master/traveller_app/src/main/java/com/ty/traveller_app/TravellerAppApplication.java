package com.ty.traveller_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravellerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravellerAppApplication.class, args);
	}

}
