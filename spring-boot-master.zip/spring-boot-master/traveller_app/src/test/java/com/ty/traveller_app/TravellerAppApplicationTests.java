package com.ty.traveller_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravellerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
