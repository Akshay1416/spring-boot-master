package com.ty.coworkspace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoworkspaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
