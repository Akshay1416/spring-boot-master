package com.ty.coworkspace.util;

public enum Role {

	ADMIN,MANAGER,STAFF;
}
