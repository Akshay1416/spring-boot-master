package com.ty.coworkspace;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoworkspaceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoworkspaceApplication.class, args);
	}

}
