package com.ty.coworkspace.util;

import jakarta.persistence.Entity;

 public enum Type {

	AC,NON_AC,BOARD_ROOM,CAFETARIA,CONFERENCE_ROOM,WASH_ROOM
}
